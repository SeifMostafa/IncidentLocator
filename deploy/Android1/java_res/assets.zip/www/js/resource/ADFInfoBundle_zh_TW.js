/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_zh_TW.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_zh_TW={
"WARN_SKIP_REMOTE_WRITE":"\u6c92\u6709 Java \u53ef\u7528, \u5c07\u6703\u7565\u904e\u9060\u7aef\u5beb\u5165.",
"LBL_WARNING_DISPLAY_STR":"\u8b66\u544a",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"\u4f7f\u7528\u5f15\u6578\u7684 Selenium \u6e2c\u8a66\u8b66\u544a\u8a0a\u606f: {0}",
"LBL_CONFIRMATION_DISPLAY_STR":"\u78ba\u8a8d",
"LBL_INFO_DISPLAY_STR":"\u8cc7\u8a0a",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"\u8655\u7406 (\u79fb\u9664) \u8cc7\u6599\u8b8a\u66f4\u6642\u767c\u751f\u554f\u984c",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"\u8655\u7406 (\u66f4\u65b0) \u8cc7\u6599\u8b8a\u66f4\u6642\u767c\u751f\u554f\u984c",
"LBL_OK_DISPLAY_STR":"\u78ba\u5b9a",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"\u8655\u7406 (\u5efa\u7acb) \u8cc7\u6599\u8b8a\u66f4\u6642\u767c\u751f\u554f\u984c",
"LBL_FATAL_DISPLAY_STR":"\u56b4\u91cd",
"WARN_PROCESSING_VAR_CHANGES":"\u8655\u7406\u8b8a\u6578\u8b8a\u66f4\u6642, processDataChangeEvent \u767c\u751f\u932f\u8aa4",
"LBL_ERROR_DISPLAY_STR":"\u932f\u8aa4",
"WARN_COLLECTION_MODEL_NOT_FOUND":"\u627e\u4e0d\u5230\u96c6\u5408\u6a21\u578b",
"WARN_UNABLE_TO_FETCH_SET":"\u7121\u6cd5\u64f7\u53d6\u96c6\u5408",
"WARN_UPDATING_CACHE":"\u56e0\u767c\u751f\u8cc7\u6599\u8b8a\u66f4\u4e8b\u4ef6\u800c\u66f4\u65b0\u5feb\u53d6\u6642\u767c\u751f\u554f\u984c.",
"WARN_PROCESSING_PROVIDER_CHANGES":"\u8655\u7406\u63d0\u4f9b\u8005\u8b8a\u66f4\u6642, processDataChangeEvent \u767c\u751f\u932f\u8aa4.",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
